﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Handin2_1
{
    public class Noter
    {
        public virtual long _NoteID { get; set; }
        public virtual string _Noter { get; set; }

    }
}