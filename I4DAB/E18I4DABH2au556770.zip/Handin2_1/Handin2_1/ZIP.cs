﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Handin2_1
{
    public class ZIP
    {
        public virtual long _ZipID { get; set; }
        public virtual long _ZIPListeID { get; set; }
        public virtual string _Land { get; set; }
        public virtual string _By { get; set; }
        public virtual string _PostNummer { get; set; }
    }
}
